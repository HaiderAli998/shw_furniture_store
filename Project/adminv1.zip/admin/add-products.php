<? require("../requires/connection.php"); ?>
<table width="80%" border="1" align="center">
   <? include("header.php"); ?>
  <tr>
    <td height="463" align="center" valign="middle">
	<form name="myform" action="add-process.php" method="post" enctype="multipart/form-data" >
	<table width="80%" border="0">
  <tr>
    <td height="33" colspan="2" style="font-weight:bold" ><? 
									if($_GET)
									{
									if($_GET['status']=='yes') echo "<span style='color:green'>Record Entered Successfully!</span>"; 
									else "<span style='color:red'>Sorry There is some issue, Try Again</span>"; 
									}?></td>
  </tr>
   <tr>
    <td height="34" colspan="2"><strong>Add Product</strong></td>
  </tr>
  <tr>
    <td>Product Name</td>
    <td><input type="text" name="prodName" value="" /></td>
  </tr>
   <tr>
    <td>Product Price</td>
    <td><input type="text" name="prodPrice" value="" /></td>
  </tr>
   <tr>
    <td valign="top">Product Details</td>
    <td valign="top"><textarea cols="80" rows="15" name="prodDetails"></textarea></td>
  </tr>
  
    <td>Product Status</td>
    <td><select name="prodStatus" >
		<option value="Y" >Published</option>
		<option value="N" >Not Published</option>
		</select></td>
  </tr> 
  <tr>
   	 <td valign="top">Picture</td>
    <td valign="top"><input type="file" value="" name="picture"  /></td>
   </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Add Product" /></td>
  </tr>
</table>
</form>
	
	</td>
  </tr>
  <tr>
    <td align="center" >Copyright Webeng</td>
  </tr>
</table>

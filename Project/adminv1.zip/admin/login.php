
<?php
require("../requires/connection.php"); 
$myusername = $_POST['myusername']; 
$mypassword = $_POST['mypassword'];
		$encriptedPass=md5($mypassword);
		$sql="SELECT * FROM tblusers WHERE username='$myusername' and userpassword='$encriptedPass'";
		$result=mysqli_query($connection,$sql);
		
		$count=mysqli_num_rows($result);
		
		// If result matched $myuseqrname and $mypassword, table row must be 1 row
		if($count==1)
		{
		// Register $myusername, $mypassword and redirect to file "login_success.php"
		session_start();
		
		$_SESSION['username']=$myusername;
		$_SESSION['password']=$mypassword;
		
		header("Location: welcome.php");
		exit( );
		}
		else 
		{
		echo "Wrong Username or Password";
		}


?>
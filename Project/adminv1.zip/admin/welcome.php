<?php require("../requires/connection.php"); ?>
<table width="80%" border="1" align="center">
  <?php include("header.php"); ?>
  
  
  <tr>
    <td height="291" align="center" valign="middle">WELCOME TO HOME PAGE</td>
  </tr>
  <tr>
    <td align="center" >Copyright Webeng</td>
  </tr>
</table>

<?php session_start(); 
//echo $_SESSION['username'];


if($_SESSION['username']=="")
{
session_destroy();
header("location:index.php");
}
?>
<tr>
    <td height="77">

		<table width="100%" border="0">
		  <tr>
			<td width="64%"><h1>SAMPLE WEBSITE</h1></td>
			
			<td width="36%" align="right">Welcome <?=$_SESSION['username']?> | <a href="logout.php">Logout</a></td>
		  </tr>
		</table>
	</td>
  </tr>
  <tr>
    <td>
	<table width="100%" border="0" style="font-weight:bold; ">
	  <tr>
	  	<td width="9%"><a href="welcome.php" 		style="text-decoration:none; color:#666666" >Home</a></td>
		<td width="10%"><a href="add-products.php" 		style="text-decoration:none; color:#666666" >Add Page</a></td>
		<td width="12%"><a href="view-products.php" 	style="text-decoration:none; color:#666666" >View Pages</a></td>
		<td width="58%"><a href="welcome.php" 		style="text-decoration:none; color:#666666" >&nbsp;</a></td>
	  </tr>
	</table>

	</td>
  </tr>
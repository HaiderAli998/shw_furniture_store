<!doctype html>
<html>

    <head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
        <title>About us </title>
        <link rel="stylesheet" href="css/Style.css" type="text/css"/>
<?php include("header.php"); ?>
        <meta name="keywords" content="The best furniture in pakistan, furniture in pakistan, Pakistani modern furniture, Custom Antique furniture, antique furniture in pakistan , "/>
    </head>
    
    <body>
     <div class="container" >
    <br>
    
         <div class="row"> 
            <div class="page-header" style="color:#F1F1F1; font-size:
            160%;" >
	            <h2 style="border-bottom:dashed" >About us</h2>
                <p class="Content"  >           SHW furnitures is relatively a new Online furniture shopping website established on 2019 but the seeds of the productivity for the cheapest and best quality of furniture had been sowed into the minds of its three founders. SHW furniture allows you to buy any furniture online and pay at your own convinience. SHW furniture gives a wide range of Custom furnitures, custom antique furniture, and Modern funiture as well for younger audience. Buying furniture has never been an easier task with SHW furnitures we try our best to provide the best and qualtity cnetric furniture in the Pakistani market. The best furniture for sale in pakistan is made sure to be made avialable for the general public.  <br>
        </p>
            </div>
       </div>
       <br>
    </div>
<?php include("includes/footer.php"); ?>
</body>
</html>

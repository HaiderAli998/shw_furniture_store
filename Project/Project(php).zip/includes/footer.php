  <style>
  .footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color:#3974FF;
   color: white;
   text-align: center;
}
</style>
<br>
<br>
   <div class="footer">
  <p><a href="../Project/index.php" style="color: white;">SHW FURNITURE 2019</a> </p>
</div>

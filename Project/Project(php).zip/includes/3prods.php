<div class="container" >
	<div class="row" >
    
    <div class="col-md-1" > </div>
    	<div  class="col-md-3 box">
   <a  target="_blank" href="productdescription.php" >  <img  src="img/download.jpg" /> <u> SLATTUM </u> <br> Upholstered bed frame,light grey, Standard Double </a> </div>
<div class="col-md-3 box" > <a href="#"><img src="img/0800868_PH162809_S5.jpg"/> <u> MALM</u>  <br> Bed frame,white stained oak veneer, Luröy, Standard Double </a></div>

 <div class="col-md-3 box"> <a href="#"><img src="img/0690259_PE723183_S5.jpg"/> <u> FRIHETEN</u> <br> Corner sofa-bed with storage, Hyllie dark grey </a></div>
</div>
</div>